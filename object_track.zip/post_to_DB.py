
import requests
filename = "id.csv"
if os.path.exists(filename) :
    with open(filename, "r") as f:
            reader = csv.reader(f)
            for row in reader:
                var=row[0]
print(id)
def post_to_DB(id, nbr):
    url = 'https://ads.store.utrender.com/request_from_py.php?'
    myobj = {'id': id,'nbr':nbr}
    resp = requests.post(url, params = myobj)
    print(resp.text)
    print(resp.status_code)
    print(resp.url)