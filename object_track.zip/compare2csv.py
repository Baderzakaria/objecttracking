import csv
with open('dict.csv', 'r') as viewer_csv:  
    reader_viewer = viewer_csv.readlines()
with open('9.csv', 'r') as ids_csv:  
    reader_ids = ids_csv.readlines()
ids=[]
for row_v in reader_viewer:
    for row_i in reader_ids:
        if float(row_i.split(",")[0])/1000 >= float(row_v.split(",")[1]) and float(row_i.split(",")[0])/1000 <= (float(row_v.split(",")[1]))+10:
            #print row_i.split(",")[0] + "__a10__" + row_v.split(",")[1]
            ids.append(row_i.split(",")[1])
        elif float(row_i.split(",")[0])/1000 >= float(row_v.split(",")[1]) and float(row_i.split(",")[0])/1000<= float(row_v.split(",")[2]):
            #print str(float(row_i.split(",")[0])/1000) + "__ab__" + row_v.split(",")[1] + " " + row_v.split(",")[2]
            ids.append(row_i.split(",")[1])
        #print float(row_i.split(",")[0])/1000 -float(row_v.split(",")[1])
print ids
    